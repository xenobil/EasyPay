package com.example.easypay.activity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.easypay.Model.APILio;
import com.example.easypay.Model.Payment;
import com.example.easypay.R;
import com.example.easypay.fragments.MainFragment;
import com.example.easypay.fragments.MainFragment.OnPaymentListener;
import com.google.android.material.textfield.TextInputEditText;

import org.jetbrains.annotations.NotNull;

import cielo.orders.domain.Order;
import cielo.sdk.order.payment.PaymentError;
import cielo.sdk.order.payment.PaymentListener;

public class PaymentActivity extends AppCompatActivity implements  MainFragment.OnPaymentListener  {

    private Button startPaymentButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment);

        // Recupera o valor total do carrinho do intent
        double totalAmount = getIntent().getDoubleExtra("totalAmount", 0.0);

        // Encontra o TextInputEditText pelo ID
        TextInputEditText txValueProduct = findViewById(R.id.tx_value_product);

        // Define o texto do TextInputEditText para exibir o valor total do carrinho
        txValueProduct.setText(String.format("%.2f", totalAmount));

        // Recuperar a string extra contendo os nomes dos produtos e os preços
        String productsAndPrices = getIntent().getStringExtra("productsAndPrices");

        // Encontrar o TextView onde você deseja exibir os nomes dos produtos e os preços
        TextView productsAndPricesTextView = findViewById(R.id.products_and_prices_text_view);

        // Definir o texto do TextView com os nomes dos produtos e os preços
        productsAndPricesTextView.setText(productsAndPrices);

        // Inicializa o botão
        startPaymentButton = findViewById(R.id.pagar);


        // Configura o clique do botão para iniciar o pagamento
        startPaymentButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startPayment();
            }
        });

        // Inicia o MainFragment se a atividade estiver sendo criada pela primeira vez
        if (savedInstanceState == null) {
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.fragment_container, new MainFragment())
                    .commit();
        }
    }


    private void startPayment() {
        // Recupera o objeto de pagamento do fragmento
        MainFragment mainFragment = (MainFragment) getSupportFragmentManager().findFragmentById(R.id.fragment_container);
        Payment payment;
        payment = mainFragment.returnPayment();
        APILio apiLio = APILio.getInstance();

        try {
            // Inicializar o SDK da LIO
            apiLio.initSDK(this);

            // Inicializar um novo pedido
            apiLio.initOrder();


            // Adicionar o item de pagamento ao pedido
            apiLio.addItemToPay(payment);

            // Realizar o pagamento
            apiLio.placeOrder();

            // Lidar com os eventos de pagamento
            apiLio.payment(payment, paymentListener);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    // Lógica para lidar com eventos de pagamento
    PaymentListener paymentListener = new PaymentListener() {
        @Override
        public void onStart() {
            Log.d("PaymentActivity", "O pagamento começou.");
        }


        @Override
        public void onPayment(@NotNull Order order) {
            Log.d("PaymentActivity", "Um pagamento foi realizado.");
        }

        @Override
        public void onCancel() {
            Log.d("PaymentActivity", "A operação foi cancelada.");
        }

        @Override
        public void onError(@NotNull PaymentError paymentError) {
            Log.d("PaymentActivity", "Houve um erro no pagamento.");
        }
    };

    @Override
    public void onPaymentCompleted() {
        // Lógica para lidar com o pagamento concluído
    }
}
